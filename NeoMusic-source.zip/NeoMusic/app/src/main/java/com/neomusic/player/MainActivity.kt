package com.neomusic.player

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.Locale
import java.util.concurrent.TimeUnit

private val Bg = Color(0xFF090A0D)
private val Glass = Color(0xFF171A20)
private val GlassEdge = Color(0xFF343A44)
private val White = Color(0xFFF4F6FA)
private val Muted = Color(0xFF9BA3B2)
private val Ice = Color(0xFFB9D8F5)

data class Song(val id: Long, val title: String, val artist: String, val album: String, val uri: Uri, val folder: String, val duration: Long)

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var equalizer: Equalizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, android.content.ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try { controller = controllerFuture?.get() } catch (_: Exception) { }
        }, ContextCompat.getMainExecutor(this))
        setContent { NeoMusicApp() }
    }

    @Composable private fun NeoMusicApp() {
        var songs by remember { mutableStateOf(listOf<Song>()) }
        var hasPermission by remember { mutableStateOf(hasAudioPermission()) }
        var tab by remember { mutableStateOf("Songs") }
        var query by remember { mutableStateOf("") }
        var currentTitle by remember { mutableStateOf("Choose a track") }
        var currentArtist by remember { mutableStateOf("Your local music library") }
        var isPlaying by remember { mutableStateOf(false) }
        var position by remember { mutableLongStateOf(0L) }
        var duration by remember { mutableLongStateOf(0L) }
        var showEqualizer by remember { mutableStateOf(false) }
        var lyrics by remember { mutableStateOf(listOf<Pair<Long, String>>()) }
        var currentFolder by remember { mutableStateOf<String?>(null) }
        val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            hasPermission = granted
            if (granted) songs = loadSongs()
        }
        val lyricsPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) lyrics = readLrc(uri)
        }
        LaunchedEffect(hasPermission) { if (hasPermission) songs = loadSongs() }
        LaunchedEffect(controller, songs) {
            while (true) {
                controller?.let { c ->
                    isPlaying = c.isPlaying
                    position = c.currentPosition.coerceAtLeast(0L)
                    duration = c.duration.takeIf { it > 0 } ?: 0L
                    c.currentMediaItem?.mediaMetadata?.let { m ->
                        currentTitle = m.title?.toString() ?: currentTitle
                        currentArtist = m.artist?.toString() ?: currentArtist
                    }
                }
                kotlinx.coroutines.delay(500)
            }
        }
        val filtered = songs.filter { song ->
            (currentFolder == null || song.folder == currentFolder) &&
                (song.title.contains(query, true) || song.artist.contains(query, true) || song.album.contains(query, true))
        }
        val folders = songs.map { it.folder }.distinct().sorted()
        val activeLyric = lyrics.lastOrNull { it.first <= position }?.second ?: "Lyrics not loaded"

        MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Glass, primary = Ice, onBackground = White, onSurface = White)) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF171B23), Bg, Color(0xFF08090B))))) {
                Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 18.dp)) {
                    Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("NeoMusic", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = White, letterSpacing = (-0.8).sp)
                            Text("MUSIC, WITHOUT THE NOISE", fontSize = 9.sp, color = Muted, letterSpacing = 2.sp)
                        }
                        GlassIcon("EQ", Modifier.size(48.dp).clickable { showEqualizer = true })
                    }
                    if (!hasPermission) {
                        GlassPanel(Modifier.fillMaxWidth()) {
                            Text("Your music, your device", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(8.dp))
                            Text("Allow audio access to scan songs stored on your phone.", color = Muted)
                            Spacer(Modifier.height(14.dp))
                            Button(onClick = { permissionLauncher.launch(audioPermission()) }) { Text("Allow music access") }
                        }
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            listOf("Songs", "Folders", "Lyrics").forEach { label ->
                                val selected = tab == label
                                Box(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(if (selected) Color(0xFF303944) else Color(0x551A1D23)).clickable { tab = label }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                                    Text(label, color = if (selected) White else Muted, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
                                }
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        if (tab == "Songs" || tab == "Folders") {
                            OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search songs, artists…", color = Muted) }, shape = RoundedCornerShape(18.dp), colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = GlassEdge, focusedBorderColor = Ice, unfocusedContainerColor = Color(0x6612161C), focusedContainerColor = Color(0x8812161C)))
                            Spacer(Modifier.height(10.dp))
                        }
                        when (tab) {
                            "Folders" -> {
                                if (currentFolder != null) TextButton(onClick = { currentFolder = null }) { Text("← All folders", color = Ice) }
                                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                                    if (currentFolder == null) itemsIndexed(folders.filter { it.contains(query, true) }) { _, folder ->
                                        GlassRow(folder.substringAfterLast('/').ifBlank { "Music" }, "${songs.count { it.folder == folder }} tracks", "▤") { currentFolder = folder }
                                    } else itemsIndexed(filtered) { index, song -> SongRow(song, index) { playSongs(filtered, index) } }
                                }
                            }
                            "Lyrics" -> {
                                GlassPanel(Modifier.fillMaxWidth()) {
                                    Text("LYRICS", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                                    Spacer(Modifier.height(12.dp))
                                    Text(currentTitle, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                                    Text(currentArtist, color = Muted)
                                    Spacer(Modifier.height(20.dp))
                                    Text(activeLyric, fontSize = 18.sp, color = Ice, lineHeight = 28.sp)
                                    Spacer(Modifier.height(16.dp))
                                    OutlinedButton(onClick = { lyricsPicker.launch("text/*") }) { Text("Load .LRC lyrics") }
                                    Text("Choose a timestamped .lrc file. Synced lines follow playback time.", color = Muted, fontSize = 12.sp)
                                }
                                Spacer(Modifier.weight(1f))
                            }
                            else -> {
                                if (songs.isEmpty()) {
                                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text("No audio tracks found yet", color = Muted) }
                                } else {
                                    Text("YOUR LIBRARY  ·  ${filtered.size} TRACKS", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp, modifier = Modifier.padding(vertical = 10.dp))
                                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                                        itemsIndexed(filtered) { index, song -> SongRow(song, index) { playSongs(filtered, index) } }
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        PlayerPanel(currentTitle, currentArtist, isPlaying, position, duration, onPlay = { controller?.let { if (it.isPlaying) it.pause() else it.play() } }, onNext = { controller?.seekToNextMediaItem() }, onPrevious = { controller?.seekToPreviousMediaItem() }, onSeek = { controller?.seekTo(it) })
                        Spacer(Modifier.height(10.dp))
                    }
                }
                if (showEqualizer) EqualizerSheet(onDismiss = { showEqualizer = false }, onEnable = { enableEqualizer() })
            }
        }
    }

    private fun playSongs(list: List<Song>, index: Int) {
        val c = controller ?: return
        val items = list.map { song -> MediaItem.Builder().setUri(song.uri).setMediaMetadata(MediaMetadata.Builder().setTitle(song.title).setArtist(song.artist).setAlbumTitle(song.album).build()).build() }
        c.setMediaItems(items, index, 0L); c.prepare(); c.play()
    }

    private fun hasAudioPermission(): Boolean = ContextCompat.checkSelfPermission(this, audioPermission()) == PackageManager.PERMISSION_GRANTED
    private fun audioPermission(): String = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun loadSongs(): List<Song> {
        val result = mutableListOf<Song>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.RELATIVE_PATH, MediaStore.Audio.Media.DURATION)
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val pathCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.RELATIVE_PATH)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                result += Song(id, cursor.getString(titleCol) ?: "Unknown title", cursor.getString(artistCol)?.takeIf { it != "<unknown>" } ?: "Unknown artist", cursor.getString(albumCol) ?: "Unknown album", ContentUris.withAppendedId(collection, id), cursor.getString(pathCol) ?: "Music", cursor.getLong(durationCol))
            }
        }
        return result
    }

    private fun readLrc(uri: Uri): List<Pair<Long, String>> = runCatching {
        contentResolver.openInputStream(uri)?.bufferedReader()?.useLines { lines ->
            lines.flatMap { line ->
                val regex = Regex("\\[(\\d{2}):(\\d{2})(?:[.](\\d{1,3}))?]\\s*(.*)")
                regex.findAll(line).map { match ->
                    val millis = match.groupValues[1].toLong() * 60_000 + match.groupValues[2].toLong() * 1_000 + match.groupValues[3].padEnd(3, '0').ifBlank { "0" }.toLong()
                    millis to match.groupValues[4]
                }
            }.sortedBy { it.first }.toList()
        } ?: emptyList()
    }.getOrDefault(emptyList())

    private fun enableEqualizer() {
        runCatching {
            val sessionId = PlaybackService.audioSessionId
            if (sessionId != 0) {
                equalizer?.release()
                equalizer = Equalizer(0, sessionId).apply { enabled = true }
            }
        }
    }

    override fun onDestroy() {
        equalizer?.release(); equalizer = null
        controller?.release(); controller = null
        controllerFuture?.let { MediaController.releaseFuture(it) }; controllerFuture = null
        super.onDestroy()
    }

    @Composable private fun GlassIcon(text: String, modifier: Modifier = Modifier) {
        Box(modifier.clip(RoundedCornerShape(17.dp)).background(Brush.linearGradient(listOf(Color(0xFF343B46), Color(0xFF111318)))).padding(1.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF191D24)), contentAlignment = Alignment.Center) { Text(text, color = Ice, fontWeight = FontWeight.Bold) }
    }

    @Composable private fun GlassPanel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
        Column(modifier.clip(RoundedCornerShape(26.dp)).background(Brush.linearGradient(listOf(Color(0xDD282E38), Color(0xB512151B)))).padding(1.dp).clip(RoundedCornerShape(25.dp)).background(Color(0xCC15181E)).padding(18.dp), content = content)
    }

    @Composable private fun GlassRow(title: String, subtitle: String, icon: String, onClick: () -> Unit) {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(19.dp)).background(Color(0x99171A20)).clickable(onClick = onClick).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Color(0xFF414B59), Color(0xFF1B2028)))), contentAlignment = Alignment.Center) { Text(icon, color = Ice, fontSize = 20.sp) }
            Column(Modifier.weight(1f).padding(start = 12.dp)) { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium); Text(subtitle, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
            Text("›", color = Muted, fontSize = 25.sp)
        }
    }

    @Composable private fun SongRow(song: Song, index: Int, onClick: () -> Unit) = GlassRow(song.title, song.artist + "  ·  " + formatTime(song.duration), "♫", onClick)

    @Composable private fun PlayerPanel(title: String, artist: String, playing: Boolean, position: Long, duration: Long, onPlay: () -> Unit, onNext: () -> Unit, onPrevious: () -> Unit, onSeek: (Long) -> Unit) {
        val transition = rememberInfiniteTransition(label = "album")
        val pulse by transition.animateFloat(initialValue = 0.96f, targetValue = 1.04f, animationSpec = infiniteRepeatable(tween(1500), RepeatMode.Reverse), label = "pulse")
        GlassPanel(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(58.dp).clip(RoundedCornerShape(17.dp)).background(Brush.linearGradient(listOf(Color(0xFF667789), Color(0xFF252B35)))).then(if (playing) Modifier.alpha(pulse) else Modifier), contentAlignment = Alignment.Center) { Text("♫", fontSize = 30.sp, color = White) }
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text(title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(artist, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Text(if (playing) "PLAYING" else "READY", color = Ice, fontSize = 9.sp, letterSpacing = 1.sp)
            }
            Spacer(Modifier.height(8.dp))
            Slider(value = if (duration > 0) position.toFloat().coerceIn(0f, duration.toFloat()) else 0f, onValueChange = { onSeek(it.toLong()) }, valueRange = 0f..(duration.coerceAtLeast(1L).toFloat()), colors = SliderDefaults.colors(thumbColor = Ice, activeTrackColor = Ice, inactiveTrackColor = GlassEdge))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(formatTime(position), color = Muted, fontSize = 10.sp); Text(formatTime(duration), color = Muted, fontSize = 10.sp) }
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Text("|◀", color = White, fontSize = 23.sp, modifier = Modifier.clickable { onPrevious() }.padding(12.dp))
                Box(Modifier.size(58.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFFE7F1FB), Ice))).clickable { onPlay() }, contentAlignment = Alignment.Center) { Text(if (playing) "Ⅱ" else "▶", color = Color(0xFF10141A), fontSize = 23.sp, fontWeight = FontWeight.Bold) }
                Text("▶|", color = White, fontSize = 23.sp, modifier = Modifier.clickable { onNext() }.padding(12.dp))
            }
        }
    }

    @Composable private fun EqualizerSheet(onDismiss: () -> Unit, onEnable: () -> Unit) {
        var enabled by remember { mutableStateOf(false) }
        var preset by remember { mutableStateOf("Flat") }
        Box(Modifier.fillMaxSize().background(Color(0xAA000000)), contentAlignment = Alignment.BottomCenter) {
            GlassPanel(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Equalizer", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); TextButton(onClick = onDismiss) { Text("Close") } }
                Text("Android audio effect · availability varies by device", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Flat", "Bass", "Vocal", "Treble").forEach { p -> FilterChip(selected = preset == p, onClick = { preset = p }, label = { Text(p) }) } }
                Spacer(Modifier.height(8.dp))
                Text("Enable the device equalizer when a playback session is active.", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                Button(onClick = { enabled = !enabled; if (enabled) onEnable() }, modifier = Modifier.fillMaxWidth()) { Text(if (enabled) "Equalizer requested" else "Enable equalizer") }
            }
        }
    }

    private fun formatTime(ms: Long): String {
        val seconds = TimeUnit.MILLISECONDS.toSeconds(ms.coerceAtLeast(0L))
        return String.format(Locale.US, "%d:%02d", seconds / 60, seconds % 60)
    }
}
