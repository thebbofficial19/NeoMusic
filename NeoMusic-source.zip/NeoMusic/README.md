# NeoMusic — Android music player

A native Android music-player starter project using Kotlin, Jetpack Compose and AndroidX Media3.

## Included

- Dark glass-style interface with subtle glass-edge treatment
- Local audio library scan using Android MediaStore
- Search by title, artist and album
- Folder grouping from MediaStore relative paths
- Playback queue built from the visible song list
- Background playback via `MediaSessionService` and Media3 notification/media controls
- LRC lyrics import with timestamp-based line following
- Device Android Equalizer integration attempt (device/OEM dependent)
- Animated now-playing artwork placeholder/pulse

## Build the APK from a phone (cloud build)

This project includes `.github/workflows/build-apk.yml` so it can be built without a laptop:

1. Create/sign in to a GitHub account in your phone browser.
2. Create a new **public or private** repository named `NeoMusic`.
3. Upload the contents of this folder to the repository root (not the outer `NeoMusic` folder itself).
4. Open the repository's **Actions** tab and enable Actions if asked.
5. Choose **Build NeoMusic APK** → **Run workflow**.
6. When the run finishes, open it and download the `NeoMusic-debug-apk` artifact. GitHub may require sign-in to download artifacts.
7. Extract the downloaded ZIP on your phone, tap `app-debug.apk`, and allow “Install unknown apps” for the browser/file manager if Android asks.

The workflow builds a **debug APK**, suitable for personal testing. It is not a Play Store release-signed APK.

## Build locally

Requires JDK 17, Android SDK platform 35 and Gradle 8.9-compatible setup. From this directory run:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Notes / limitations

- This source project is supplied as a starter implementation and has not been device-tested in this environment.
- Album art currently uses an animated abstract tile rather than decoding each file's embedded cover art.
- Lyrics are loaded by selecting a local `.lrc` text file; automatic lyric discovery/download is not included.
- Equalizer availability and behavior vary by phone vendor and Android version.
- The folder view groups audio tracks by their MediaStore relative path. It does not grant broad filesystem access.
